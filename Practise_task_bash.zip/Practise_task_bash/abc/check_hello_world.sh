#!/bin/bash

if grep -q "hello world" "$1"; then
    echo "Yes"
else
    echo "Not"
fi
