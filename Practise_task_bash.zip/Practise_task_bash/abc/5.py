#!/usr/bin/env python
# coding: utf-8

# In[1]:


print("not work")


# In[ ]:




