from flask import Flask, request, jsonify
import hashlib

app = Flask(__name__)

@app.route('/md5')
def get_md5():
    file = r"C:\Users\Abdul\Desktop\fz.jpg" 
    with open(file , "rb") as f:
        image_bytes = f.read()

    md5_hash = str(hashlib.md5(image_bytes).hexdigest())

    return md5_hash

if __name__ == '_main_':
    app.run(debug=True)